"""Independent 2D inter-island boundary/containment review, no GPU.

Uses the actual packed coordinates. Boundary proximity is spatially indexed
with4px line samples,8px cells and two neighbouring cells (covering every pair
closer than10px). Containment uses a filled-triangle representative per chart.
Existing within-island overlaps are not re-certified: the affine proof shows
their state is unchanged from the previous authored chart.
"""
import argparse,json,hashlib,math,time
from pathlib import Path
from collections import defaultdict
import numpy as np
ap=argparse.ArgumentParser();ap.add_argument('candidate',type=Path);ap.add_argument('--out-name',default='island-separation-review.json');a=ap.parse_args();started=time.monotonic();d=np.load(a.candidate/'census-arrays.npz');uv=np.load(a.candidate/'candidate-lighting-uv.npy').astype(float);old=d['uv'];faces=d['faces'];island=d['island'];n=len(uv)
keys=np.column_stack([faces.reshape(-1).astype(np.uint64),old.reshape(-1,2).view('<u4').reshape(-1,2).astype(np.uint64)]);_,ci=np.unique(keys,axis=0,return_inverse=True);ci=ci.reshape(-1,3);edge_pairs=[(0,1),(1,2),(2,0)];edges=np.concatenate([np.sort(ci[:,pair],axis=1)for pair in edge_pairs]);faceids=np.tile(np.arange(n),3);localpair=np.repeat(np.arange(3),n);order=np.lexsort((edges[:,1],edges[:,0]));s=edges[order];starts=np.r_[0,np.flatnonzero(np.any(s[1:]!=s[:-1],axis=1))+1];ends=np.r_[starts[1:],len(order)];counts=ends-starts;chosen=order[starts[counts!=2]];fi=faceids[chosen];pairs=localpair[chosen];segments=np.array([uv[f,list(edge_pairs[e])]for f,e in zip(fi,pairs)])*4096;owners=island[fi];lo=segments.min(axis=1);hi=segments.max(axis=1)
def cross(x,y):return x[0]*y[1]-x[1]*y[0]
def point_segment(p,a,b):
 v=b-a;t=np.clip((p-a)@v/max(1e-30,v@v),0,1);return float(np.linalg.norm(p-a-t*v))
def distance(x,y):
 a,b=x;c,d=y;aa=cross(b-a,c-a);bb=cross(b-a,d-a);cc=cross(d-c,a-c);dd=cross(d-c,b-c)
 if aa*bb<=0 and cc*dd<=0 and np.all(np.maximum(x.min(axis=0),y.min(axis=0))<=np.minimum(x.max(axis=0),y.max(axis=0))):return 0.
 return min(point_segment(a,c,d),point_segment(b,c,d),point_segment(c,a,b),point_segment(d,a,b))
grid=defaultdict(list);minimum=float('inf');closest=None;comparisons=0;crossings=[]
for i,seg in enumerate(segments):
 steps=max(1,int(math.ceil(np.linalg.norm(seg[1]-seg[0])/4)));points=np.linspace(seg[0],seg[1],steps+1);cells=set(map(tuple,np.floor(points/8).astype(int)));seen=set()
 for cx,cy in cells:
  for dx in range(-2,3):
   for dy in range(-2,3):
    for k in grid.get((cx+dx,cy+dy),()):
     if k in seen or owners[k]==owners[i]:continue
     seen.add(k)
     if np.any(np.maximum(lo[i],lo[k])-np.minimum(hi[i],hi[k])>10):continue
     delta=distance(seg,segments[k]);comparisons+=1
     if delta<minimum:minimum=delta;closest={'segments':[int(i),int(k)],'islands':[int(owners[i]),int(owners[k])],'pixelDistance':delta}
     if delta<.001 and len(crossings)<25:crossings.append(closest.copy())
 for cell in cells:grid[cell].append(i)
print(json.dumps({'phase':'boundary','segments':len(segments),'comparisons':comparisons,'minimumPixels':minimum}),flush=True)
# A completely contained chart could avoid all boundary crossings. Its largest
# filled triangle centroid must lie in the containing chart's triangle union.
pixeluv=uv*4096;lower=pixeluv.min(axis=1);upper=pixeluv.max(axis=1);tri_area=np.abs(np.cross(pixeluv[:,1]-pixeluv[:,0],pixeluv[:,2]-pixeluv[:,0]))*.5;cells=defaultdict(list)
for i in range(n):
 xy0=np.floor(lower[i]/64).astype(int);xy1=np.floor(upper[i]/64).astype(int)
 for x in range(xy0[0],xy1[0]+1):
  for y in range(xy0[1],xy1[1]+1):cells[x,y].append(i)
sort=np.argsort(island,kind='stable');vals=island[sort];st=np.r_[0,np.flatnonzero(vals[1:]!=vals[:-1])+1];en=np.r_[st[1:],n];contained=[];tested=0
for start,end in zip(st,en):
 ids=sort[start:end];rep=ids[int(tri_area[ids].argmax())];p=pixeluv[rep].mean(axis=0);c=np.asarray(cells[tuple(np.floor(p/64).astype(int))],dtype=int);c=c[(island[c]!=island[rep])&np.all(p>lower[c]+1e-8,axis=1)&np.all(p<upper[c]-1e-8,axis=1)];tested+=1
 if not len(c):continue
 t=pixeluv[c];v0=t[:,1]-t[:,0];v1=t[:,2]-t[:,0];v2=p-t[:,0];den=v0[:,0]*v1[:,1]-v0[:,1]*v1[:,0];valid=np.abs(den)>1e-14;c=c[valid];v0=v0[valid];v1=v1[valid];v2=v2[valid];den=den[valid];b=(v2[:,0]*v1[:,1]-v2[:,1]*v1[:,0])/den;g=(v0[:,0]*v2[:,1]-v0[:,1]*v2[:,0])/den;hit=c[(b>1e-8)&(g>1e-8)&(b+g<1-1e-8)]
 if len(hit):contained.append({'containedIsland':int(island[rep]),'containingIslands':list(map(int,np.unique(island[hit]))),'representative':p.tolist()})
report={'schema':1,'status':'PASS'if not crossings and not contained and minimum>=3.99 else'REVIEW','candidateUvSha256':hashlib.sha256((a.candidate/'candidate-lighting-uv.npy').read_bytes()).hexdigest(),'boundarySegmentsReviewed':len(segments),'nonmanifoldEdgeGroups':int((counts>2).sum()),'crossIslandBoundaryComparisonsWithinExpanded10pxBoxes':comparisons,'minimumObservedInterIslandBoundaryGapPixels':minimum if math.isfinite(minimum)else None,'gapSearchRadiusPixels':10,'closestPair':closest,'crossings':crossings,'filledRepresentativesTested':tested,'fullyContainedChartOverlaps':contained,'elapsedSeconds':time.monotonic()-started,'limits':['Existing within-island overlap is unchanged by the independently verified uniform affine chart transforms.','This checks distinct chart boundary separation and full containment; it does not certify semantic source visibility or final denoising/mip bleeding.','Four source pixels of padding become two pixels after2K AO resizing; mapped images still need review.'],'generatorSha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()};(a.candidate/a.out_name).write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2),flush=True)
