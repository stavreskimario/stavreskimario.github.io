"""Prepare a reviewable baker patch/copy externally; never edit the repository."""
from pathlib import Path
import argparse,hashlib,json,difflib,shutil
ap=argparse.ArgumentParser();ap.add_argument('--model-dir',type=Path,required=True);ap.add_argument('--out',type=Path,required=True);a=ap.parse_args();assert not a.out.exists();a.out.mkdir(parents=True);src=a.model_dir/'bake_lighting.py';original=src.read_text();text=original
needle='parser.add_argument("--ao-only", action="store_true")';assert text.count(needle)==1;text=text.replace(needle,needle+'\nparser.add_argument("--preserve-authored-uv1", action="store_true", help="Arcade-only: retain an existing two-UV baked authoring mesh without joining, welding or re-unwrapping")')
needle='started = time.monotonic()';assert text.count(needle)==1;text=text.replace(needle,'if args.preserve_authored_uv1 and (artifact_zone != "arcade-enclosure" or args.surface_group != "all"):\n    raise ValueError("Preserve-authored-UV1 is restricted to the arcade authoring artifact")\nif args.preserve_authored_uv1 and args.materials:\n    raise ValueError("Preserve-authored-UV1 retains authored PBR and UV0; omit --materials")\n'+needle)
needle='primary_objects = list(scene.objects)';assert text.count(needle)==2;text=text.replace(needle,needle+'\nauthored_primary_snapshot = None\nif args.preserve_authored_uv1:\n    from authored_lighting_uv_guard import snapshot_primary, verify_before_bake\n    authored_primary_snapshot = snapshot_primary(primary_objects)',1)
begin=text.index('arcade_normal_integrity = None\n');end=text.index('mesh.calc_loop_triangles()',begin);old=text[begin:end]
preserve='''authored_uv_integrity = None
if args.preserve_authored_uv1:
    if len(solids) != 1:
        raise RuntimeError("Preserve-authored-UV1 requires one already-batched opaque architecture mesh")
    architecture = solids[0]
    if not np.array_equal(np.array(architecture.matrix_world), np.eye(4)):
        raise RuntimeError("Preserve-authored-UV1 requires the authored Street0 identity transform")
    mesh = architecture.data
    if len(mesh.uv_layers) != 2:
        raise RuntimeError("Preserve-authored-UV1 needs its original surface UV0 and authored lighting UV1")
    original_uv = mesh.uv_layers[0].name
    light_uv_name = mesh.uv_layers[1].name
    order_uv_audit = None
    vault_normal_integrity = None
    bpy.ops.object.select_all(action="DESELECT")
    architecture.select_set(True)
    bpy.context.view_layer.objects.active = architecture
    authored_uv_integrity, arcade_normal_integrity = verify_before_bake(authored_primary_snapshot, architecture)
else:
'''
text=text[:begin]+preserve+''.join('    '+line if line.strip()else line for line in old.splitlines(keepends=True))+text[end:]
needle='if arcade_normal_integrity is not None:\n    report["arcadeNormalIntegrity"] = arcade_normal_integrity';assert text.count(needle)==1
guard_start=text.index(needle);guard_end=text.index('if not args.ao_only',guard_start);visibility_block=text[guard_start:guard_end];assert 'report["sourceRenderVisibility"]'in visibility_block
text=text[:guard_start]+visibility_block+'if authored_uv_integrity is not None:\n    report["authoredUvIntegrity"] = authored_uv_integrity\n'+text[guard_end:]
compile(text,str(src),'exec');(a.out/'bake_lighting.py').write_text(text);shutil.copy2(Path(__file__).with_name('authored_lighting_uv_guard.py'),a.out/'authored_lighting_uv_guard.py')
for name in ['material_library.py','render_device.py','arcade_corner_normals.py','order_lighting_uv.py','vault_lighting_uv.py','restore_imported_visibility.py']:shutil.copy2(a.model_dir/name,a.out/name)
patch=''.join(difflib.unified_diff(original.splitlines(keepends=True),text.splitlines(keepends=True),fromfile='a/penn-station-1935/model/bake_lighting.py',tofile='b/penn-station-1935/model/bake_lighting.py'));(a.out/'bake-preserve-authored-uv1.patch').write_text(patch)
H=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();report={'schema':1,'status':'EXTERNAL PROTOTYPE: source untouched','originalBakerSha256':H(src),'copiedSources':{p.name:H(p)for p in a.out.glob('*.py')},'patchSha256':H(a.out/'bake-preserve-authored-uv1.patch'),'defaultBehavior':'Unchanged existing preparation branch, now under explicit false-by-default preserve flag. Existing occluder/visibility code is untouched.','preserveBehavior':'One already-batched identity-frame mesh, exactly two UV sets, no join/transform/weld/unwrap/normal rewrite; verify all imported primary buffers byte-exact before any bake.'};(a.out/'prototype-source-proof.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
