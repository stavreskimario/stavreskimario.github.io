# Arcade lighting UV priority handoff

This package contains a CPU-authored, reproducible UV1 reallocation. No geometry, surface UV0, normal, material or source-visibility data was changed by the UV-only authoring patch. The candidate requires freshly baked maps.

At the same4K atlas size, occupancy rises30.86%→60.77%. Median GI densities rise approximately12.2→47.8texels/m on the Ionic envelope,11.7→33.7 on the inner vault,12.2→33.5 on public inner walls and12.2→27.5 on the four public floor additions. Lower-priority footing/outer-face geometry stays present and participates in transport.

8178 true islands require a complete common physical edge with equal endpoint UVs. Each existing chart is scaled as a whole, using an area-weighted RMS priority and a minimum2.3 for the four floor-containing charts. The immutable-input GLB patch changes only UV1 accessor bytes. Replay was byte-identical in the pinned Blender4.3 environment; compare hashes on another platform.

## Actual executed source and correction

`actual-bake-v4-source/` is EXACTLY the source used for the4K256-sample bake. Keep it unchanged as evidence. Its two guards require authored geometry/UVs/normals/visibility to stay byte-identical after import and require only the architecture selected/active before baking. Materials preparation is rejected in preserve mode. The original source-visibility/hidden-template restoration remains active.

That actual source exported the previous AO through an imported glTF settings group. The completed GI and standalone AO are valid. `repair_baked_ao_binding.py` appended the exact fresh AO PNG and redirected its shared image binding, preserving the whole old binary prefix and every other JSON field. The receipt proves9e9ec877→7588be27. This requires no rebake.

`future-bake-v5-source/` is the separately tested future fix. It updates Occlusion on every existing recognized export-settings group instead of adding a second competing group. All old material nodes and non-AO links remain. Its CPU export regression resolves all11 lit materials to the exact fresh AO PNG bytes. Do not replace the recorded actual-v4 source with this later fix.

## Production patch for root review

`patches/production-preserve-and-fresh-ao.patch` targets the current root baker935aecc0 and adds the preserve mode, imported-buffer/selection guard and fresh-AO rewire helper. It does not change default geometry preparation or the source-visibility loop. Root must review/apply it; it has not been applied by this task.

## Portable replay

Use Python3.11, bpy4.3.0, NumPy<2 and Pillow13.0.0. Inputs are the UNQUANTIZED source4cd4dbbf and raw bake96e370b4; never use runtime compressed UVs.

    uv run --offline --no-project --python 3.11 --with bpy==4.3.0 --with 'numpy<2' python source/lighting_uv/atlas_priority_review.py --source /path/to/source.glb --baked /path/to/raw-bake.glb --out ./replay --pack
    uv run --offline --no-project --python 3.11 --with 'numpy<2' python source/lighting_uv/validate_priority_pack.py ./replay
    uv run --offline --no-project --python 3.11 --with 'numpy<2' python source/lighting_uv/write_uv_only_candidate.py --baked /path/to/raw-bake.glb --uv ./replay/candidate-lighting-uv.npy --out ./uv-only

They accept explicit paths; the package import layout is portable. The saved UV array is also provided gzipped under `data/`. The established archives retain large input models and maps; `input-identities.json` pins them.

## Separation and filtering limits

Independent review checked122714 boundary segments,561457 nearby cross-chart pairs and a filled representative of every chart. There are no cross-chart intersections/containments; the measured minimum boundary gap is7.9989source pixels. Whole-chart affine residual is below8.9e-8UV and no shared corner splits. Existing within-chart overlap state is unchanged, not newly certified.

Four source pixels of padding per chart become two after2K AO resizing; GI/colour-only denoising and distant mip levels can still blur across boundaries. Review the actual mapped images. The normal appearance issue is compression loss plus the separate authored strength, not proven double application. The historic mural remains at its recovered native resolution.
