"""Frozen external atlas bake launcher; run only after root review."""
from pathlib import Path
import hashlib,json,subprocess,sys,time
BASE=Path(__file__).resolve().parent
PACKET=BASE/'priority-bake-inputs-v1.json'
EXPECTED_PACKET='37e0b0910d16ef8cc42128a24390ceed8979196323442448c52fdf7035cb199d'
H=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert H(PACKET)==EXPECTED_PACKET,'Reviewed priority packet changed'
r=json.loads(PACKET.read_text());verified=[]
for item in [r['primary'],r['rawSource'],r['previousBake'],r['sourceVisibilityProof'],r['canonicalSource'],*r['occluders'],*r['reviewReceipts'],*r['bakeSources']]:
 assert H(item['path'])==item['sha256'],item['path'];verified.append(item)
assert '--materials'not in r['arguments'],'Retain authored PBR/UV0 without material preparation'
assert '--preserve-authored-uv1'in r['arguments'];out=Path(r['arguments'][r['arguments'].index('--out')+1]);assert not out.exists(),'Fresh bake output only'
start={'schema':1,'status':'START: reviewed UV-priority bake','packetSha256':EXPECTED_PACKET,'verifiedFiles':verified,'command':[r['bakerPath'],*r['arguments']],'unixTime':time.time()};(BASE/'priority-bake-start-v1.json').write_text(json.dumps(start,indent=2)+'\n');print(json.dumps(start),flush=True);t=time.monotonic();result=subprocess.run([sys.executable,r['bakerPath'],*r['arguments']])
for item in [r['primary'],r['rawSource'],r['previousBake'],r['canonicalSource']]:assert H(item['path'])==item['sha256'],'Input/source changed during bake'
report=out/'lighting-arcade-enclosure.json';stats=json.loads(report.read_text())if report.exists()else None
if result.returncode==0:
 assert stats['authoredUvIntegrity']['allImportedPrimaryBuffersByteExactBeforeBake']
 assert stats['authoredUvIntegrity']['onlyArchitectureSelectedAndActiveBeforeBake']
 assert stats['arcadeNormalIntegrity']['status']=='PASS'
 assert stats['sourceRenderVisibility']['proofSha256']==r['sourceVisibilityProof']['sha256']
 assert len(stats['sourceRenderVisibility']['contexts'])==len(r['occluders'])
finish={'schema':1,'status':'PASS: raw priority bake completed; denoise/packing/browser remain'if result.returncode==0 else'FAIL: raw priority bake stopped; do not promote','returncode':result.returncode,'elapsedSeconds':time.monotonic()-t,'packetSha256':EXPECTED_PACKET,'stats':stats,'outputs':{p.name:{'bytes':p.stat().st_size,'sha256':H(p)}for p in out.iterdir()if p.is_file()}if out.exists()else{}};(BASE/'priority-bake-completion-v1.json').write_text(json.dumps(finish,indent=2)+'\n');print(json.dumps(finish),flush=True);raise SystemExit(result.returncode)
