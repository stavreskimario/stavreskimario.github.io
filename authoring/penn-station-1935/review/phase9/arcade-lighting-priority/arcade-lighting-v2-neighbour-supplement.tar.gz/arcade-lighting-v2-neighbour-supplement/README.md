# V2 supplement: restore the original neighbour appearance

This supplements the first portable UV-priority handoff. Keep that package and its exact actual-v4 source, UV-only input proof and9e9→7588 AO repair history. No prior frozen input/source/output was mutated.

The first priority bake omitted global material preparation to preserve its already-correct primary UV0/PBR. That also omitted the old material setup on imported neighbours. It is held for publication. This actual-v6 source restores the original library ONLY on imported neighbour meshes/materials via `--occluder-materials`. It rejects shared primary/neighbour mesh or material pointers and proves primary node graphs, packed-image bytes/properties and imported geometry/UVs/normals remain unchanged.

CPU preflight restored EXACTLY all21 original neighbour profile records. The old v5 report had30total:9primary profiles already embedded in the authored input plus21neighbour profiles. The library code and all23 image files match the old actual bake hashes.39neighbour material graphs and447UV0 mesh datasets actually change, so this is a required appearance restoration, not a speculative rebake.

`actual-v6-source/` is the exact frozen source for the second priority bake. It includes the tested fresh-AO group reuse/rewire fix, the selected-only-active architecture guard and the original source-visibility restoration. The running invocation is recorded under `proofs/`; do not describe its output as passed before its completion report and browser review.

`production-v6-neighbour-delta.patch` targets the current committed v5 baker28851c0b (aa1a08a). It adds only the explicit neighbour flag, actual imported-object collection, scoped material application, strong primary-material proof and report. Root reviews/applies it; this task has not edited production.

All large per-object preflight hashes are gzip-only. Input model/image binaries remain in established archives. The actual old96e→first priority7588 export check found positions andUV0exact, all13material JSON/node transforms exact; Blender normal re-encoding was bounded by0.144degrees and is explicitly reported rather than claimed byte-exact.
